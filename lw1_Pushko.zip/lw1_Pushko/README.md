Запуск и компиляция кода:

```bash
mkdir build
cd build
cmake ..
make -j16
ctest -j16
```